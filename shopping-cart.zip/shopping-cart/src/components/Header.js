import React from "react";
import { Container } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import { faSearch, faShoppingCart, faUser } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import Logo from '../img/logo.png';

const Header = () => {

    return (
        <>
            <header className="header">
                <Container className="d-flex justify-content-between">
                    <Link to={'/'} className="logo"><img src={Logo} alt="" /> </Link>
                    <div className="input-group search">
                        <span className="input-group-text" id="basic-addon1">
                            <FontAwesomeIcon icon={faSearch} className="icon" />
                        </span>
                        <input type="text" className="form-control" placeholder="Search for Products..." />
                    </div>
                    <div className="right-btn d-flex">
                        <button><FontAwesomeIcon icon={faShoppingCart} /></button>
                        <button><FontAwesomeIcon icon={faUser} /></button>
                    </div>
                </Container>
            </header>
        </>
    )
}

export default Header;