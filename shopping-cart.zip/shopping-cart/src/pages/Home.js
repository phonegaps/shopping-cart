import React from "react";
import { Container } from 'react-bootstrap';
import Header from '../components/Header';
import Footer from '../components/Footer';
import ProductList from '../pages/products/ProductList';


const Home = () => {

    return (
        <>
            <Header />
            <Container className="home-wrap">
                <div className="categoryList">
                    <button className="cat-item">EGGS, MEAT AND FISH</button>
                    <button className="cat-item">Menupass</button>
                    <button className="cat-item">Ayurveda</button>
                    <button className="cat-item">Buy More Save More</button>
                    <button className="cat-item">Deals of the Week</button>
                    <button className="cat-item">Combo store</button>
                </div>

                <ProductList />
            </Container>
            <Footer />
        </>
    )
}

export default Home;