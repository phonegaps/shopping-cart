import React from "react";
import './Product.scss';
import { Row, Col } from 'react-bootstrap';
import { Link } from "react-router-dom";
import { faHeart } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import VegImg1 from '../../img/veg1.jpg';
import VegImg2 from '../../img/veg2.jpg';
import VegImg3 from '../../img/veg3.jpg';
import VegImg4 from '../../img/veg4.jpg';


const ProductList = () => {
    return (
        <>
            <div className="product-wrapp">
                <h2>My Smart Basket</h2>

                <Row className="productList">
                    <Col sm={6} md={4} lg={3}>
                        <div className="productItem">
                            <Link to={'/productDetails?id=1'} className="productLink" target="_blank">
                                <span className="offer">38% OFF</span>
                                <img src={VegImg1} alt="" className="productImg" />
                                <span className="greenTop"><span></span></span>
                            </Link>

                            <div className="prductTitle">
                                <span>Fresho</span>
                                <p>Capsicum - Green (Loose)</p>
                            </div>
                            <div className="productPrice">
                                <select className="form-select" defaultValue={'2'}>
                                    <option value="2">1 kg</option>
                                    <option value="1">2 kg</option>
                                    <option value="3">500 g</option>
                                    <option value="4">250 g</option>
                                </select>
                                <p>₹68 <span>₹109.59</span></p>
                            </div>
                            <div className="addtoCart">
                                <FontAwesomeIcon icon={faHeart} className="icon" />
                                <button>ADD</button>
                            </div>
                        </div>
                    </Col>
                    <Col sm={6} md={4} lg={3}>
                        <div className="productItem">
                            <Link to={'/productDetails?id=2'} className="productLink" target="_blank">
                                <span className="offer">58% OFF</span>
                                <img src={VegImg2} alt="" className="productImg" />
                                <span className="greenTop"><span></span></span>
                            </Link>

                            <div className="prductTitle">
                                <span>Fresho</span>
                                <p>Carrot - Orange (Loose)</p>
                            </div>
                            <div className="productPrice">
                                <select className="form-select" defaultValue={'2'}>
                                    <option value="2">1 kg</option>
                                    <option value="1">2 kg</option>
                                    <option value="3">500 g</option>
                                    <option value="4">250 g</option>
                                </select>
                                <p>₹50 <span>₹106.85</span></p>
                            </div>
                            <div className="addtoCart">
                                <FontAwesomeIcon icon={faHeart} className="icon" />
                                <button>ADD</button>
                            </div>
                        </div>
                    </Col>
                    <Col sm={6} md={4} lg={3}>
                        <div className="productItem">
                            <Link to={'/productDetails?id=3'} className="productLink" target="_blank">
                                <span className="offer">29% OFF</span>
                                <img src={VegImg3} alt="" className="productImg" />
                                <span className="greenTop"><span></span></span>
                            </Link>

                            <div className="prductTitle">
                                <span>Fresho</span>
                                <p>Cauliflower</p>
                            </div>
                            <div className="productPrice">
                                <select className="form-select" defaultValue={'2'}>
                                    <option value="2" >1 kg</option>
                                    <option value="1">2 kg</option>
                                    <option value="3">500 g</option>
                                    <option value="4">250 g</option>
                                </select>
                                <p>₹31 <span>₹43.84</span></p>
                            </div>
                            <div className="addtoCart">
                                <FontAwesomeIcon icon={faHeart} className="icon" />
                                <button>ADD</button>
                            </div>
                        </div>
                    </Col>
                    <Col sm={6} md={4} lg={3}>
                        <div className="productItem">
                            <Link to={'/productDetails?id=4'} className="productLink" target="_blank">
                                <span className="offer">40% OFF</span>
                                <img src={VegImg4} alt="" className="productImg" />
                                <span className="greenTop"><span></span></span>
                            </Link>

                            <div className="prductTitle">
                                <span>Fresho</span>
                                <p>Coriander Leaves</p>
                            </div>
                            <div className="productPrice">
                                <select className="form-select" defaultValue={'2'}>
                                    <option value="2">1 kg</option>
                                    <option value="1">2 kg</option>
                                    <option value="3">500 g</option>
                                    <option value="4">250 g</option>
                                </select>
                                <p>₹140 <span>₹191.78</span></p>
                            </div>
                            <div className="addtoCart">
                                <FontAwesomeIcon icon={faHeart} className="icon" />
                                <button>ADD</button>
                            </div>
                        </div>
                    </Col>
                </Row>
            </div>
        </>
    )
}

export default ProductList;