import React, { useState } from "react";
import './Product.scss';
import { Container, Row, Col } from 'react-bootstrap';
import { faHome } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import Header from '../../components/Header';
import Footer from '../../components/Footer';
import { Link } from "react-router-dom";

import VegImg1 from '../../img/veg1.jpg';
import VegImg11 from '../../img/veg11.jpg';
import VegImg12 from '../../img/veg12.jpg';
import VegImg13 from '../../img/veg13.jpg';
import VegImg14 from '../../img/veg14.jpg';

import VegImg2 from '../../img/veg2.jpg';

import VegImg3 from '../../img/veg3.jpg';
import VegImg31 from '../../img/veg31.jpg';
import VegImg32 from '../../img/veg32.jpg';

import VegImg4 from '../../img/veg4.jpg';
import VegImg41 from '../../img/veg41.jpg';
import VegImg42 from '../../img/veg42.jpg';
import VegImg43 from '../../img/veg43.jpg';

const productDetails = [
    {
        id: 1,
        name: 'Capsicum - Green (Loose)',
        imgList: [VegImg1, VegImg11, VegImg12, VegImg13, VegImg14],
        price: '₹109.59',
        offerPrice: '₹68',
        offerPercent: '38%'
    },
    {
        id: 2,
        name: 'Carrot - Orange (Loose)',
        imgList: [VegImg2, VegImg12],
        price: '₹106.85',
        offerPrice: '₹50',
        offerPercent: '58%'
    },
    {
        id: 3,
        name: 'Cauliflower',
        imgList: [VegImg3, VegImg31, VegImg12, VegImg32],
        price: '₹43.84',
        offerPrice: '₹31',
        offerPercent: '29%'
    },
    {
        id: 4,
        name: 'Coriander Leaves',
        imgList: [VegImg4, VegImg41, VegImg42, VegImg43, VegImg12],
        price: '₹191.78',
        offerPrice: '₹140',
        offerPercent: '40%'
    }
]

const ProductDetails = () => {
    const [showImg, setShowImg] = useState(0)
    let currUrl = window.location.href;
    currUrl = currUrl.split('=');
    let productId = parseInt(currUrl[1]);

    const changePic = (index) => {
        setShowImg(index)
    }

    return (
        <>
            <Header />
            <Container className="productDetails-wrap">
                <div className="d-flex breadcrumbs">
                    <Link to={'/'}><FontAwesomeIcon icon={faHome} className="pe-2" /></Link>
                    <Link to={'/'}>Fruits & vegetables </Link>
                    <Link to={'/'}>Fresh vegetables </Link>
                    <p>Capsicum</p>
                </div>
                <Row className="productDetails">
                    <Col md={6} className="d-flex pro-images">
                        <ul className="imgList">
                            {productDetails.map((item) => (
                                productId === item.id &&
                                item.imgList.map((itemImg, index) => (
                                    <li key={index} onClick={() => changePic(index)}><img src={itemImg} alt="" /></li>
                                ))
                            ))}
                        </ul>

                        {productDetails.map((item, index) => (
                            productId === item.id && <img src={item.imgList[showImg]} key={index} alt="" className="proBigImg" />
                        ))}

                    </Col>
                    <Col md={6}>
                        <div className="productDescription">
                            <p className="textCat"><span>Fresho</span></p>
                            {productDetails.map((item, index) => (
                                productId === item.id &&

                                <div key={index}>
                                    <p className="name">{item.name}</p>
                                    <p className="mrpPrice">MRP: {item.price}</p>
                                    <p className="offerPrice">Price : {item.offerPrice}</p>
                                    <p className="offerPercent">You Save: {item.offerPercent} OFF </p>
                                    <p className="inclusiveTax">(inclusive of all taxes)</p>

                                    <div className="d-flex justify-content-between">
                                        <button className="addToCart">Add to Basket</button>
                                        <button className="saveFor">Save for later</button>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </Col>
                </Row>
            </Container>
            <Footer />
        </>
    )
}

export default ProductDetails;